ipKita = 20
haha = {'TEAMS': {'Team #{}'.format(i): '127.0.0.{}'.format(i)
              for i in range(1, 20 + 1) if i != ipKita}}

print(haha["TEAMS"])