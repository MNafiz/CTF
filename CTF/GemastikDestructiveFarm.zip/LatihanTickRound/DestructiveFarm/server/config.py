kamus = {'data': [{'username': 'Solid3x', 'ip': '10.100.101.101'}, {'username': 'Gak Bahaya Ta?', 'ip': '10.100.101.102'}, {'username': 'Kessoku Band', 'ip': '10.100.101.103'}, {'username': 'CP Enjoyer', 'ip': '10.100.101.104'}, {'username': 'Calon Mantune Bapakmu', 'ip': '10.100.101.105'}, {'username': 'Apa Adanya', 'ip': '10.100.101.106'}, {'username': 'Hantu Siber', 'ip': '10.100.101.107'}, {'username': 'sehad', 'ip': '10.100.101.108'}, {'username': 'aezakmi_POLIBATAM', 'ip': '10.100.101.109'}, {'username': 'anak kemaren sore', 'ip': '10.100.101.110'}, {'username': 'Moai', 'ip': '10.100.101.111'}, {'username': 'Peserta', 'ip': '10.100.101.112'}, {'username': 'Jejaring Jagat Gembar', 'ip': '10.100.101.113'}, {'username': 'TCP1P', 'ip': '10.100.101.114'}, {'username': 'Kerang Ajaib', 'ip': '10.100.101.115'}, {'username': 'apanii', 'ip': '10.100.101.116'}, {'username': 'Big Brain Kidz', 'ip': '10.100.101.117'}, {'username': 'is_admin=true', 'ip': '10.100.101.118'}, {'username': 'AcRtf', 'ip': '10.100.101.119'}, {'username': 'buff me pls', 'ip': '10.100.101.120'}], 'success': True}


CONFIG = {
    # Don't forget to remove the old database (flags.sqlite) before each competition.

    # The clients will run sploits on TEAMS and
    # fetch FLAG_FORMAT from sploits' stdout.
    'TEAMS': {dt["username"]: dt["ip"]
              for dt in kamus["data"]},
    'FLAG_FORMAT': r'GEMASTIK{[a-f0-9]*}',

    # This configures how and where to submit flags.
    # The protocol must be a module in protocols/ directory.

    'SYSTEM_PROTOCOL': 'ructf_http',
    #'SYSTEM_HOST': '127.0.0.1',
    #'SYSTEM_PORT': 1337,

    # 'SYSTEM_PROTOCOL': 'ructf_http',
    # 'SYSTEM_URL': 'http://127.0.0.1:1337/flag',
    'SYSTEM_URL' : 'https://ctf-gemastik.ub.ac.id/api/flag',
    'SYSTEM_TOKEN': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6IjU0ZTVmNmIzLWM2OWYtNDZmZS1iZDVjLTgyM2FmMGIzYzA5YiIsIlVzZXJuYW1lIjoiQmlnIEJyYWluIEtpZHoiLCJJc0FkbWluIjpmYWxzZSwiZXhwIjoxNjk0NTc2ODk3fQ.oyibd3ajVR8APXK_be89lW6hnHj3VFFQ4ygpaZ-s03s',

    # 'SYSTEM_PROTOCOL': 'volgactf',
    # 'SYSTEM_HOST': '127.0.0.1',

    # 'SYSTEM_PROTOCOL': 'forcad_tcp',
    # 'SYSTEM_HOST': '127.0.0.1',
    # 'SYSTEM_PORT': 31337,
    # 'TEAM_TOKEN': 'your_secret_token',

    # The server will submit not more than SUBMIT_FLAG_LIMIT flags
    # every SUBMIT_PERIOD seconds. Flags received more than
    # FLAG_LIFETIME seconds ago will be skipped.
    'SUBMIT_FLAG_LIMIT': 50,
    'SUBMIT_PERIOD': 5,
    'FLAG_LIFETIME': 5 * 60,

    # Password for the web interface. You can use it with any login.
    # This value will be excluded from the config before sending it to farm clients.
    'SERVER_PASSWORD': 'BBKWINGEMASTIK123',

    # Use authorization for API requests
    'ENABLE_API_AUTH': False,
    'API_TOKEN': '00000000000000000000'
}
